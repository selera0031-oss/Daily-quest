package com.example.daily_quest;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
